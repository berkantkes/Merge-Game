public enum ItemType
{
    Generator,
    Product
}