using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "P1Family", menuName = "Items/P1Family")]
public class P1FamilySO : BaseBoardItemFamilySO
{
    
}