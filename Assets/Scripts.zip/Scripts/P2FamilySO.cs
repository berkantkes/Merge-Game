using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "P2Family", menuName = "Items/P2Family")]
public class P2FamilySO : BaseBoardItemFamilySO
{
}