using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "G1Family", menuName = "Items/G1Family")]
public class ItemGeneratorSO : BaseBoardItemFamilySO
{
    public List<GeneratorData> GeneratorData;
}

[System.Serializable]
public class GeneratorData
{
    public int GeneratorLevel;
    public List<GenerateItemsData> _GenerateItemsDatas;
}

[System.Serializable]
public struct GenerateItemsData
{
    public BoardItemFamilyType BoardItemFamilyType;
    public int GenerateItemLevel;
    public float Possibility;
}
