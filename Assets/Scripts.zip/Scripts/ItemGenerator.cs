using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemGenerator : MonoBehaviour
{
    [SerializeField] private ItemGeneratorSO _itemGeneratorSo;
    
    private GridManager _gridManager;

    public void Initialize(GridManager gridManager)
    {
        _gridManager = gridManager;
    }

    public void CreateNewItem()
    {
        
    }
    
}
