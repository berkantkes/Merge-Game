using System.Collections.Generic;
using UnityEngine;

public abstract class BaseBoardItemFamilySO : ScriptableObject
{
    public List<ItemData> FamilyData;
}
