using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "G1Family", menuName = "Items/G1Family")]
public class G1FamilySO : BaseBoardItemFamilySO
{
    
}