public enum BoardItemFamilyType
{
    G1Family,
    P1Family,
    P2Family
}