using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour
{
    [SerializeField] private LevelDataSO _levelDataSo;
    [SerializeField] private ItemController _itemController;

    private ObjectPoolManager _objectPoolManager;
    private int _initialPoolSize = 10;
    
    public void Initialize(ObjectPoolManager objectPoolManager)
    {
        _objectPoolManager = objectPoolManager;
        
        _objectPoolManager.CreatePool(_itemController, _initialPoolSize);
        
        foreach (var startingItem in _levelDataSo.StartingItems)
        {
            ItemController item = _objectPoolManager.Get<ItemController>(transform);
            // item.Initialize(startingItem.Level, startingItem.ItemData.Icon, startingItem.ItemData.ItemType,
            //     startingItem.ItemData.BoardItemFamilyType);
        }
    }
}
