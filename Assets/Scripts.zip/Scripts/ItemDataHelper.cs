using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemDataHelper : MonoBehaviour
{
    [SerializeField] private List<BaseBoardItemFamilySO> allFamilies;

    private void BuildItemTypeLookup()
    {
        foreach (var familySO in allFamilies)
        {
            for (int level = 1; level <= familySO.MaxLevel; level++)
            {
                var (itemType, _, _) = familySO.GetItemInfoByLevel(level);
                var key = (level, familySO.FamilyType);

                if (!itemTypeLookup.ContainsKey(key))
                    itemTypeLookup.Add(key, itemType);
            }
        }
    }

}
